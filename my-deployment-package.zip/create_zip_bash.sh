zip -r my-deployment-package.zip ./src
cd ./lib/python3.9/site-packages
zip -r my-deployment-package.zip .
