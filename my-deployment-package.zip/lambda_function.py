import json
from sync_gcal_from_timetracker_api import main

def lambda_handler(event, context):
    main()
